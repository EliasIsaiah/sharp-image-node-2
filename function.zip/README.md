# sharp-image-node-2
https://docs.aws.amazon.com/lambda/latest/dg/with-s3-example.html
